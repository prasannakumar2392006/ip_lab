
<?php
session_start();
require_once __DIR__ . "/includes/db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$role = $_SESSION["role"] ?? "student";

// Students can view only their own records.
// Teachers can view records for subjects they teach.
if ($role === "teacher") {
    $stmt = $conn->prepare(
        "SELECT
            a.attendance_date,
            a.status,
            u.name AS student_name,
            u.email AS student_email,
            s.subject_name,
            s.subject_code
         FROM attendance a
         JOIN users u ON a.student_id = u.id
         JOIN subjects s ON a.subject_id = s.id
         WHERE s.teacher_id = ?
         ORDER BY a.attendance_date DESC, s.subject_name, u.name"
    );
} else {
    $stmt = $conn->prepare(
        "SELECT
            a.attendance_date,
            a.status,
            s.subject_name,
            s.subject_code
         FROM attendance a
         JOIN subjects s ON a.subject_id = s.id
         WHERE a.student_id = ?
         ORDER BY a.attendance_date DESC, s.subject_name"
    );
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$records = [];
$present = 0;
$absent = 0;
$late = 0;

while ($row = $result->fetch_assoc()) {
    $records[] = $row;

    if ($row["status"] === "Present") {
        $present++;
    } elseif ($row["status"] === "Absent") {
        $absent++;
    } elseif ($row["status"] === "Late") {
        $late++;
    }
}

$stmt->close();

$total = count($records);
$percentage = $total > 0
    ? round(($present / $total) * 100, 2)
    : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Report</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px 15px;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
            color: #1e293b;
        }

        .container {
            max-width: 1100px;
            margin: 15px auto;
            padding: 28px;
            background: white;
            border-radius: 14px;
            box-shadow: 0 5px 20px #dce4f0;
        }

        h1 {
            color: #2449d8;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 25px 0;
        }

        .card {
            padding: 20px;
            border-radius: 10px;
            background: #f1f5ff;
        }

        .card h3 {
            margin-top: 0;
            font-size: 15px;
            color: #64748b;
        }

        .number {
            font-size: 26px;
            font-weight: bold;
            color: #2449d8;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }

        th {
            background: #eef2ff;
        }

        .present {
            color: #15803d;
            font-weight: bold;
        }

        .absent {
            color: #b91c1c;
            font-weight: bold;
        }

        .late {
            color: #b45309;
            font-weight: bold;
        }

        .empty {
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
        }

        .links {
            margin-top: 25px;
        }

        .links a {
            margin-right: 15px;
            color: #2449d8;
        }
    </style>
</head>

<body>
<div class="container">

    <h1>Attendance Report</h1>

    <?php if ($role === "teacher"): ?>
        <p>Attendance records for students in your subjects.</p>
    <?php else: ?>
        <p>
            Welcome,
            <?= htmlspecialchars($_SESSION["name"] ?? "Student") ?>.
            Here is your attendance history.
        </p>
    <?php endif; ?>

    <section class="cards">
        <div class="card">
            <h3>Total Records</h3>
            <div class="number"><?= $total ?></div>
        </div>

        <div class="card">
            <h3>Present</h3>
            <div class="number"><?= $present ?></div>
        </div>

        <div class="card">
            <h3>Absent</h3>
            <div class="number"><?= $absent ?></div>
        </div>

        <div class="card">
            <h3>Late</h3>
            <div class="number"><?= $late ?></div>
        </div>

        <div class="card">
            <h3>Attendance Percentage</h3>
            <div class="number"><?= $percentage ?>%</div>
        </div>
    </section>

    <h2>Attendance History</h2>

    <?php if (empty($records)): ?>

        <div class="empty">
            No attendance records found yet.
        </div>

    <?php else: ?>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <?php if ($role === "teacher"): ?>
                            <th>Student Name</th>
                            <th>Email</th>
                        <?php endif; ?>

                        <th>Subject</th>
                        <th>Subject Code</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <?php if ($role === "teacher"): ?>
                            <td>
                                <?= htmlspecialchars($record["student_name"]) ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($record["student_email"]) ?>
                            </td>
                        <?php endif; ?>

                        <td>
                            <?= htmlspecialchars($record["subject_name"]) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($record["subject_code"]) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($record["attendance_date"]) ?>
                        </td>

                        <td class="<?= strtolower($record["status"]) ?>">
                            <?= htmlspecialchars($record["status"]) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="export.php">Download CSV Report</a>
        <?php if ($role === "teacher"): ?>
            <a href="attendance.php">Mark Attendance</a>
            <a href="subjects.php">Manage Subjects</a>
        <?php endif; ?>

        <a href="logout.php">Logout</a>
    </div>

</div>
</body>
</html>
