
<?php
session_start();
require_once __DIR__ . "/includes/db.php";

$message = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $department = trim($_POST["department"] ?? "");
    $year = (int)($_POST["year"] ?? 0);
    $password = $_POST["password"] ?? "";

    if (
        $name === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $department === "" ||
        $year < 1 ||
        $year > 10 ||
        strlen($password) < 8
    ) {
        $message = "Enter valid details. Password must be at least 8 characters.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare(
            "INSERT INTO users
            (name, email, password, department, year, role)
            VALUES (?, ?, ?, ?, ?, 'teacher')"
        );

        $stmt->bind_param(
            "ssssi",
            $name,
            $email,
            $hash,
            $department,
            $year
        );

        try {
            $stmt->execute();
            $message = "Teacher account created successfully! You can now log in.";
            $success = true;
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) {
                $message = "This email is already registered.";
            } else {
                error_log($e->getMessage());
                $message = "Unable to create the account. Please try again.";
            }
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Registration</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
        }

        .container {
            max-width: 450px;
            margin: 20px auto;
            padding: 30px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px #dce4f0;
        }

        h1 {
            text-align: center;
            color: #2449d8;
        }

        label {
            display: block;
            margin-top: 16px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 7px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 22px;
            border: none;
            border-radius: 7px;
            background: #2449d8;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 12px;
            border-radius: 6px;
            background: #e8f7ec;
            color: #166534;
        }

        .error {
            background: #fff0f0;
            color: #b42318;
        }

        .link {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: #2449d8;
        }
    </style>
</head>

<body>
<div class="container">
    <h1>Teacher Registration</h1>

    <p>Create a teacher account for the Attendance Management System.</p>

    <?php if ($message !== ""): ?>
        <p class="message <?= !$success ? 'error' : '' ?>">
            <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
        </p>
    <?php endif; ?>

    <form method="POST" action="teacher_register.php">
        <label for="name">Teacher Name</label>
        <input type="text" id="name" name="name" maxlength="100" required>

        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" maxlength="150" required>

        <label for="department">Department</label>
        <input type="text" id="department" name="department" maxlength="100" required>

        <label for="year">Year (enter 1)</label>
        <input type="number" id="year" name="year" min="1" max="10" value="1" required>

        <label for="password">Password (minimum 8 characters)</label>
        <input type="password" id="password" name="password" minlength="8" required>

        <button type="submit">Create Teacher Account</button>
    </form>

    <p class="link">
        <a href="login.php">Go to Login</a>
    </p>

    <p class="link">
        <a href="dashboard.php">Back to Dashboard</a>
    </p>
</div>
</body>
</html>
