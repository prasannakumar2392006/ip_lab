
<?php
session_start();
require_once __DIR__ . "/includes/db.php";

// Only logged-in teachers can mark attendance.
if (
    !isset($_SESSION["user_id"]) ||
    ($_SESSION["role"] ?? "") !== "teacher"
) {
    header("Location: login.php");
    exit;
}

$teacher_id = (int) $_SESSION["user_id"];
$message = "";
$message_type = "success";

// Load subjects belonging to this teacher.
$stmt = $conn->prepare(
    "SELECT id, subject_name, subject_code
     FROM subjects
     WHERE teacher_id = ?
     ORDER BY subject_name"
);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$subjects_result = $stmt->get_result();

$subjects = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects[] = $row;
}
$stmt->close();

$selected_subject = (int) (
    $_POST["subject_id"] ?? $_GET["subject_id"] ?? 0
);

// Verify that the selected subject belongs to this teacher.
$valid_subject = false;

foreach ($subjects as $subject) {
    if ((int) $subject["id"] === $selected_subject) {
        $valid_subject = true;
        break;
    }
}

if (!$valid_subject) {
    $selected_subject = 0;
}

// Save attendance when the teacher submits the form.
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["save_attendance"])) {
    $attendance_date = $_POST["attendance_date"] ?? "";
    $statuses = $_POST["status"] ?? [];

    $date_object = DateTime::createFromFormat("!Y-m-d", $attendance_date);
    $valid_date = $date_object &&
        $date_object->format("Y-m-d") === $attendance_date;

    if (!$valid_subject) {
        $message = "Please select a valid subject.";
        $message_type = "error";
    } elseif (!$valid_date || $attendance_date > date("Y-m-d")) {
        $message = "Please select a valid date that is not in the future.";
        $message_type = "error";
    } elseif (!is_array($statuses) || empty($statuses)) {
        $message = "No student attendance was submitted.";
        $message_type = "error";
    } else {
        // Confirm that submitted student IDs belong to the database.
        $student_result = $conn->query(
            "SELECT id FROM users WHERE role = 'student'"
        );

        $valid_student_ids = [];
        while ($student = $student_result->fetch_assoc()) {
            $valid_student_ids[] = (int) $student["id"];
        }

        $allowed_statuses = ["Present", "Absent", "Late"];
        $clean_statuses = [];
        $invalid_submission = false;

        foreach ($statuses as $student_id => $status) {
            $student_id = filter_var(
                $student_id,
                FILTER_VALIDATE_INT
            );

            if (
                !$student_id ||
                !in_array((int) $student_id, $valid_student_ids, true) ||
                !in_array($status, $allowed_statuses, true)
            ) {
                $invalid_submission = true;
                break;
            }

            $clean_statuses[(int) $student_id] = $status;
        }

        if ($invalid_submission || empty($clean_statuses)) {
            $message = "Invalid attendance data. Please reload and try again.";
            $message_type = "error";
        } else {
            try {
                $conn->begin_transaction();

                $save_stmt = $conn->prepare(
                    "INSERT INTO attendance
                    (student_id, subject_id, attendance_date, status, marked_by)
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    status = VALUES(status),
                    marked_by = VALUES(marked_by)"
                );

                foreach ($clean_statuses as $student_id => $status) {
                    $save_stmt->bind_param(
                        "iissi",
                        $student_id,
                        $selected_subject,
                        $attendance_date,
                        $status,
                        $teacher_id
                    );
                    $save_stmt->execute();
                }

                $conn->commit();
                $save_stmt->close();

                $message = "Attendance saved successfully!";
                $message_type = "success";
            } catch (Throwable $e) {
                $conn->rollback();
                error_log($e->getMessage());

                $message = "Could not save attendance. Please check the database and try again.";
                $message_type = "error";
            }
        }
    }
}

// Load students and any attendance already saved for this subject/date.
$students = [];

if ($valid_subject) {
    $date_for_display = $_POST["attendance_date"]
        ?? date("Y-m-d");

    $student_stmt = $conn->prepare(
        "SELECT
            u.id,
            u.name,
            u.email,
            a.status
         FROM users u
         LEFT JOIN attendance a
            ON a.student_id = u.id
            AND a.subject_id = ?
            AND a.attendance_date = ?
         WHERE u.role = 'student'
         ORDER BY u.name"
    );

    $student_stmt->bind_param(
        "is",
        $selected_subject,
        $date_for_display
    );
    $student_stmt->execute();

    $student_result = $student_stmt->get_result();

    while ($row = $student_result->fetch_assoc()) {
        $students[] = $row;
    }

    $student_stmt->close();
} else {
    $date_for_display = date("Y-m-d");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px 15px;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
            color: #1e293b;
        }

        .container {
            max-width: 1050px;
            margin: 15px auto;
            padding: 28px;
            background: white;
            border-radius: 14px;
            box-shadow: 0 5px 20px #dce4f0;
        }

        h1 {
            color: #2449d8;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        select, input[type="date"] {
            width: 100%;
            padding: 11px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: white;
        }

        button, .btn {
            display: inline-block;
            padding: 12px 18px;
            margin-top: 18px;
            border: none;
            border-radius: 7px;
            background: #2449d8;
            color: white;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
        }

        .message {
            padding: 13px;
            border-radius: 7px;
            background: #e8f7ec;
            color: #166534;
        }

        .error {
            background: #fff0f0;
            color: #b42318;
        }

        .table-wrapper {
            overflow-x: auto;
            margin-top: 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }

        th {
            background: #eef2ff;
        }

        td select {
            min-width: 120px;
        }

        .links {
            margin-top: 25px;
        }

        .links a {
            margin-right: 15px;
            color: #2449d8;
        }

        .empty {
            padding: 18px;
            background: #f8fafc;
            border-radius: 7px;
        }
    </style>
</head>

<body>
<div class="container">

    <h1>Mark Student Attendance</h1>
    <p>Select a subject and date, then mark each student's attendance.</p>

    <?php if ($message !== ""): ?>
        <p class="message <?= $message_type === "error" ? "error" : "" ?>">
            <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
        </p>
    <?php endif; ?>

    <?php if (empty($subjects)): ?>

        <div class="empty">
            <p>You have not added any subjects yet.</p>
            <a class="btn" href="subjects.php">Add a Subject</a>
        </div>

    <?php else: ?>

        <form method="GET" action="attendance.php">
            <label for="subject_id">Select Subject</label>

            <select id="subject_id" name="subject_id" required>
                <option value="">-- Choose a subject --</option>

                <?php foreach ($subjects as $subject): ?>
                    <option
                        value="<?= (int) $subject["id"] ?>"
                        <?= $selected_subject === (int) $subject["id"] ? "selected" : "" ?>
                    >
                        <?= htmlspecialchars($subject["subject_code"]) ?>
                        -
                        <?= htmlspecialchars($subject["subject_name"]) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Load Students</button>
        </form>

        <?php if ($valid_subject): ?>

            <?php if (empty($students)): ?>
                <p class="empty">
                    No student accounts have been registered yet.
                </p>
            <?php else: ?>

                <form method="POST" action="attendance.php">
                    <input
                        type="hidden"
                        name="subject_id"
                        value="<?= $selected_subject ?>"
                    >

                    <label for="attendance_date">Attendance Date</label>
                    <input
                        type="date"
                        id="attendance_date"
                        name="attendance_date"
                        value="<?= htmlspecialchars($date_for_display) ?>"
                        max="<?= date("Y-m-d") ?>"
                        required
                    >

                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Student Name</th>
                                    <th>Email</th>
                                    <th>Attendance Status</th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td>
                                        <?= htmlspecialchars($student["name"]) ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($student["email"]) ?>
                                    </td>

                                    <td>
                                        <select
                                            name="status[<?= (int) $student["id"] ?>]"
                                            required
                                        >
                                            <option value="Present"
                                                <?= $student["status"] === "Present" ? "selected" : "" ?>>
                                                Present
                                            </option>

                                            <option value="Absent"
                                                <?= $student["status"] === "Absent" ? "selected" : "" ?>>
                                                Absent
                                            </option>

                                            <option value="Late"
                                                <?= $student["status"] === "Late" ? "selected" : "" ?>>
                                                Late
                                            </option>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <button type="submit" name="save_attendance" value="1">
                        Save Attendance
                    </button>
                </form>

            <?php endif; ?>
        <?php endif; ?>

    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="subjects.php">Manage Subjects</a>
        <a href="logout.php">Logout</a>
    </div>

</div>
</body>
</html>
