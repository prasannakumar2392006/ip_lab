
<?php
require_once "includes/db.php";

$message = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $department = trim($_POST["department"] ?? "");
    $year = (int)($_POST["year"] ?? 0);
    $password = $_POST["password"] ?? "";

    if (
        $name === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $department === "" ||
        $year < 1 ||
        $year > 10 ||
        strlen($password) < 8
    ) {
        $message = "Please enter valid details. Password must be at least 8 characters.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare(
            "INSERT INTO users
             (name, email, password, department, year, role)
             VALUES (?, ?, ?, ?, ?, 'student')"
        );

        $stmt->bind_param(
            "ssssi",
            $name,
            $email,
            $hash,
            $department,
            $year
        );

        try {
            $stmt->execute();
            $message = "Registration successful! You can now log in.";
            $success = true;
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) {
                $message = "This email is already registered.";
            } else {
                error_log($e->getMessage());
                $message = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>

    <style>
        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
        }

        .container {
            max-width: 450px;
            margin: 20px auto;
            padding: 30px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px #dce4f0;
        }

        h1 {
            text-align: center;
            color: #2449d8;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            margin-top: 7px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 22px;
            border: none;
            border-radius: 7px;
            background: #2449d8;
            color: white;
            cursor: pointer;
        }

        .message {
            padding: 12px;
            background: #e8f7ec;
            border-radius: 6px;
        }

        .error {
            background: #fff0f0;
        }

        .link {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: #2449d8;
        }
    </style>
</head>

<body>
<div class="container">
    <h1>Student Registration</h1>

    <?php if ($message !== ""): ?>
        <p class="message <?= !$success ? 'error' : '' ?>">
            <?= htmlspecialchars($message) ?>
        </p>
    <?php endif; ?>

    <form method="POST">
        <label>Full Name</label>
        <input type="text" name="name" maxlength="100" required>

        <label>Email Address</label>
        <input type="email" name="email" maxlength="150" required>

        <label>Department</label>
        <input type="text" name="department" maxlength="100" required>

        <label>Year of Study (1–10)</label>
        <input type="number" name="year" min="1" max="10" required>

        <label>Password (minimum 8 characters)</label>
        <input type="password" name="password" minlength="8" required>

        <button type="submit">Register Now</button>
    </form>

    <p class="link">
        Already registered? <a href="login.php">Login here</a>
    </p>

    <p class="link">
        <a href="index.php">Back to Home</a>
    </p>
</div>
</body>
</html>
