
<?php
session_start();
require_once __DIR__ . "/includes/db.php";

// Allow only logged-in users.
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$name = $_SESSION["name"] ?? "Student";
$email = $_SESSION["email"] ?? "";
$role = $_SESSION["role"] ?? "student";

// Get the student's attendance summary.
$total = 0;
$present = 0;
$absent = 0;
$late = 0;
$percentage = 0;

if ($role === "student") {
    $stmt = $conn->prepare(
        "SELECT
            COUNT(*) AS total,
            SUM(status = 'Present') AS present_count,
            SUM(status = 'Absent') AS absent_count,
            SUM(status = 'Late') AS late_count
         FROM attendance
         WHERE student_id = ?"
    );

    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $summary = $stmt->get_result()->fetch_assoc();

    $total = (int) ($summary["total"] ?? 0);
    $present = (int) ($summary["present_count"] ?? 0);
    $absent = (int) ($summary["absent_count"] ?? 0);
    $late = (int) ($summary["late_count"] ?? 0);

    if ($total > 0) {
        $percentage = round(($present / $total) * 100, 2);
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Dashboard</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
            color: #1e293b;
        }

        header {
            background: #2449d8;
            color: white;
            padding: 20px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h2 {
            margin: 0;
        }

        header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            max-width: 1050px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .welcome {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px #dce4f0;
        }

        .welcome h1 {
            color: #2449d8;
            margin-top: 0;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-top: 25px;
        }

        .card {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 4px 15px #dce4f0;
        }

        .card h3 {
            margin-top: 0;
            color: #64748b;
            font-size: 16px;
        }

        .number {
            font-size: 30px;
            font-weight: bold;
            color: #2449d8;
        }

        .actions {
            margin-top: 30px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .btn {
            display: inline-block;
            padding: 13px 20px;
            border-radius: 7px;
            background: #2449d8;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .secondary {
            background: #0f766e;
        }

        @media (max-width: 500px) {
            header {
                padding: 18px;
            }

            .container {
                margin-top: 20px;
                padding: 0 14px;
            }
        }
    </style>
</head>

<body>

<header>
    <h2>Student Attendance System</h2>
    <a href="logout.php">Logout</a>
</header>

<main class="container">

    <section class="welcome">
        <h1>Welcome, <?= htmlspecialchars($name, ENT_QUOTES, "UTF-8") ?>!</h1>

        <p>Your attendance dashboard is ready.</p>

        <p>
            <strong>Email:</strong>
            <?= htmlspecialchars($email, ENT_QUOTES, "UTF-8") ?>
        </p>

        <p>
            <strong>Role:</strong>
            <?= htmlspecialchars(ucfirst($role), ENT_QUOTES, "UTF-8") ?>
        </p>
    </section>

    <?php if ($role === "student"): ?>

        <section class="cards">
            <div class="card">
                <h3>Total Attendance Records</h3>
                <div class="number"><?= $total ?></div>
            </div>

            <div class="card">
                <h3>Present</h3>
                <div class="number"><?= $present ?></div>
            </div>

            <div class="card">
                <h3>Absent</h3>
                <div class="number"><?= $absent ?></div>
            </div>

            <div class="card">
                <h3>Late</h3>
                <div class="number"><?= $late ?></div>
            </div>

            <div class="card">
                <h3>Attendance Percentage</h3>
                <div class="number"><?= $percentage ?>%</div>
            </div>
        </section>

    <?php else: ?>

        <section class="welcome" style="margin-top:25px;">
            <h2>Teacher Dashboard</h2>
            <p>Use the attendance and report sections to manage records.</p>
        </section>

    <?php endif; ?>

    <section class="actions">
        <a class="btn" href="attendance.php">View Attendance</a>
        <a class="btn secondary" href="report.php">View Attendance Report</a>
    </section>

</main>

</body>
</html>
