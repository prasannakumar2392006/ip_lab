
<?php
session_start();
require_once __DIR__ . "/includes/db.php";

// Only logged-in teachers can manage subjects.
if (
    !isset($_SESSION["user_id"]) ||
    ($_SESSION["role"] ?? "") !== "teacher"
) {
    header("Location: login.php");
    exit;
}

$message = "";
$teacher_id = (int) $_SESSION["user_id"];

// Add a new subject.
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $subject_name = trim($_POST["subject_name"] ?? "");
    $subject_code = strtoupper(trim($_POST["subject_code"] ?? ""));

    if ($subject_name === "" || $subject_code === "") {
        $message = "Please enter both subject name and subject code.";
    } elseif (
        strlen($subject_name) > 100 ||
        strlen($subject_code) > 20
    ) {
        $message = "Subject name or code is too long.";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO subjects (subject_name, subject_code, teacher_id)
             VALUES (?, ?, ?)"
        );

        $stmt->bind_param(
            "ssi",
            $subject_name,
            $subject_code,
            $teacher_id
        );

        try {
            $stmt->execute();
            $message = "Subject added successfully!";
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) {
                $message = "That subject code already exists.";
            } else {
                error_log($e->getMessage());
                $message = "Unable to add the subject. Please try again.";
            }
        }

        $stmt->close();
    }
}

// Get subjects created by this teacher.
$stmt = $conn->prepare(
    "SELECT id, subject_name, subject_code
     FROM subjects
     WHERE teacher_id = ?
     ORDER BY subject_name"
);

$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$subjects = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subjects</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
            color: #1e293b;
        }

        .container {
            max-width: 750px;
            margin: 20px auto;
            padding: 30px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px #dce4f0;
        }

        h1 {
            color: #2449d8;
        }

        label {
            display: block;
            margin-top: 16px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 7px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
        }

        button, .btn {
            display: inline-block;
            padding: 12px 18px;
            margin-top: 20px;
            border: none;
            border-radius: 7px;
            background: #2449d8;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .message {
            padding: 12px;
            background: #e8f7ec;
            border-radius: 6px;
        }

        table {
            width: 100%;
            margin-top: 25px;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }

        th {
            background: #eef2ff;
        }

        .links {
            margin-top: 25px;
        }

        .links a {
            color: #2449d8;
            margin-right: 15px;
        }
    </style>
</head>

<body>
<div class="container">

    <h1>Manage Subjects</h1>
    <p>Add subjects that you teach. Each subject needs a unique code.</p>

    <?php if ($message !== ""): ?>
        <p class="message">
            <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
        </p>
    <?php endif; ?>

    <form method="POST" action="subjects.php">
        <label for="subject_name">Subject Name</label>
        <input
            type="text"
            id="subject_name"
            name="subject_name"
            maxlength="100"
            placeholder="Example: Computer Networks"
            required
        >

        <label for="subject_code">Subject Code</label>
        <input
            type="text"
            id="subject_code"
            name="subject_code"
            maxlength="20"
            placeholder="Example: CS301"
            required
        >

        <button type="submit">Add Subject</button>
    </form>

    <h2>Your Subjects</h2>

    <?php if ($subjects->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($subject = $subjects->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($subject["subject_code"]) ?></td>
                        <td><?= htmlspecialchars($subject["subject_name"]) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No subjects added yet.</p>
    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>

</div>
</body>
</html>

<?php
$stmt->close();
?>
