<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "Step 1: PHP is working!<br>";

require_once "includes/db.php";

echo "Step 2: Database file loaded!<br>";

if ($conn->ping()) {
    echo "Step 3: Connected to attendance_db successfully!";
}
?>