
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Student Attendance Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            width: 100%;
            max-width: 900px;
            padding: 55px 30px;
            text-align: center;
            border-radius: 18px;
            box-shadow: 0 8px 30px rgba(30, 64, 175, 0.08);
        }

        h1 {
            color: #2449d8;
            font-size: 38px;
            margin-bottom: 20px;
        }

        p {
            color: #475569;
            font-size: 18px;
            line-height: 1.7;
        }

        .buttons {
            margin-top: 30px;
        }

        .btn {
            display: inline-block;
            background: #2449d8;
            color: white;
            padding: 15px 25px;
            margin: 8px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 17px;
        }

        .btn:hover {
            background: #1738b2;
        }

        .secondary {
            background: #475569;
        }

        @media (max-width: 600px) {
            h1 {
                font-size: 28px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Online Student Attendance Management System</h1>

        <p>
            Welcome to our online attendance portal.
            Manage student attendance, monitor daily presence,
            and view attendance reports in one place.
        </p>

        <div class="buttons">
            <a href="login.php" class="btn">Login</a>

            <a href="register.php" class="btn">Student Register</a>

            <a href="report.php" class="btn secondary">
                Attendance Report
            </a>
        </div>
    </div>
</body>
</html>
