
<?php
// Display errors while developing the project.
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

session_start();

require_once __DIR__ . "/includes/db.php";

$message = "";

// Redirect users who are already logged in.
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}

// Process the login form.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = strtolower(trim($_POST["email"] ?? ""));
    $password = $_POST["password"] ?? "";

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === "") {

        $message = "Please enter a valid email and password.";

    } else {

        $stmt = $conn->prepare(
            "SELECT id, name, email, password, role
             FROM users
             WHERE email = ?
             LIMIT 1"
        );

        if (!$stmt) {
            error_log($conn->error);
            $message = "Unable to process login. Please try again.";
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();

            $result = $stmt->get_result();
            $user = $result->fetch_assoc();

            if ($user && password_verify($password, $user["password"])) {

                session_regenerate_id(true);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["name"] = $user["name"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["role"] = $user["role"];

                $stmt->close();

                header("Location: dashboard.php");
                exit;

            } else {
                $message = "Incorrect email or password.";
            }

            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Attendance - Login</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 30px 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: #f1f5ff;
        }

        .container {
            width: 100%;
            max-width: 430px;
            padding: 32px;
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(36, 73, 216, 0.12);
        }

        h1 {
            margin-bottom: 10px;
            text-align: center;
            color: #2449d8;
        }

        .subtitle {
            margin-bottom: 25px;
            text-align: center;
            color: #64748b;
            line-height: 1.5;
        }

        label {
            display: block;
            margin-top: 18px;
            font-weight: bold;
            color: #334155;
        }

        input {
            width: 100%;
            padding: 13px;
            margin-top: 8px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            font-size: 15px;
        }

        input:focus {
            outline: 2px solid #c7d2fe;
            border-color: #2449d8;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            border: none;
            border-radius: 7px;
            background: #2449d8;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #1938ad;
        }

        .message {
            padding: 12px;
            margin: 15px 0;
            border-radius: 7px;
            background: #fff0f0;
            color: #b42318;
            text-align: center;
        }

        .link {
            margin-top: 22px;
            text-align: center;
            color: #475569;
        }

        a {
            color: #2449d8;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <div class="container">

        <h1>Student Login</h1>

        <p class="subtitle">
            Welcome back! Log in to your Attendance Management System.
        </p>

        <?php if ($message !== ""): ?>
            <div class="message">
                <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">

            <label for="email">Email Address</label>
            <input
                type="email"
                id="email"
                name="email"
                placeholder="Enter your registered email"
                maxlength="150"
                autocomplete="email"
                required
            >

            <label for="password">Password</label>
            <input
                type="password"
                id="password"
                name="password"
                placeholder="Enter your password"
                autocomplete="current-password"
                required
            >

            <button type="submit">Login</button>

        </form>

        <p class="link">
            Don't have an account?
            <a href="register.php">Register here</a>
        </p>

        <p class="link">
            <a href="index.php">Back to Home</a>
        </p>

    </div>

</body>
</html>
