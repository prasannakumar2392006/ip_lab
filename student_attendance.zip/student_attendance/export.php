
<?php
session_start();
require_once __DIR__ . "/includes/db.php";

// Only logged-in users can export attendance.
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$role = $_SESSION["role"] ?? "student";

if ($role === "teacher") {
    // Teachers can export records for their own subjects.
    $stmt = $conn->prepare(
        "SELECT
            u.name AS student_name,
            u.email AS student_email,
            s.subject_name,
            s.subject_code,
            a.attendance_date,
            a.status
         FROM attendance a
         JOIN users u ON u.id = a.student_id
         JOIN subjects s ON s.id = a.subject_id
         WHERE s.teacher_id = ?
         ORDER BY a.attendance_date DESC, u.name"
    );
} else {
    // Students can export only their own records.
    $stmt = $conn->prepare(
        "SELECT
            s.subject_name,
            s.subject_code,
            a.attendance_date,
            a.status
         FROM attendance a
         JOIN subjects s ON s.id = a.subject_id
         WHERE a.student_id = ?
         ORDER BY a.attendance_date DESC, s.subject_name"
    );
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Prepare the CSV download.
$filename = "attendance_report_" . date("Y-m-d") . ".csv";

header("Content-Type: text/csv; charset=UTF-8");
header(
    'Content-Disposition: attachment; filename="' . $filename . '"'
);
header("Cache-Control: no-store, no-cache, must-revalidate");

$output = fopen("php://output", "w");

// Add a UTF-8 BOM so Excel handles text correctly.
fwrite($output, "\xEF\xBB\xBF");

if ($role === "teacher") {
    fputcsv($output, [
        "Student Name",
        "Student Email",
        "Subject",
        "Subject Code",
        "Attendance Date",
        "Status"
    ]);
} else {
    fputcsv($output, [
        "Subject",
        "Subject Code",
        "Attendance Date",
        "Status"
    ]);
}

while ($row = $result->fetch_assoc()) {
    // Prevent spreadsheet formula injection in text fields.
    foreach ($row as $key => $value) {
        if (
            is_string($value) &&
            preg_match('/^[\s]*[=+\-@]/', $value)
        ) {
            $row[$key] = "'" . $value;
        }
    }

    fputcsv($output, array_values($row));
}

fclose($output);
$stmt->close();
$conn->close();
exit;
?>
